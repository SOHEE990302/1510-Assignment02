package q2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * WordCounter class to drive the Word class. 
 * It contains list of Word as an integer 
 * and parseBook method to open the file. 
 *
 * @author Sohee Hwang
 * @version 2023
 */
public class WordCounter {
    /**
     * Declare the constant variable TEN. 
     */
    public static final int TEN = 10; 
    /**
     * Create List of Word as an instance variable.
     */
    
    private List<Word> words; 
        
    /**
     * Initialize the words with an ArrayList. 
     */
    public WordCounter() {
        this.words = new ArrayList<>(); 
    }
    
    /**
     * Create a parseBook method that accepts a String as a parameter. 
     * @param fileName
     *          to open 
     * @return the total number of unique Words stored in the list 
     * @throws FileNotFoundException
     * 
     */
    public int parseBook(String fileName) {
        int uniqueWordCount = 0;

        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNext()) {
                String wordString = scanner.next().toLowerCase().
                        replaceAll("[^a-zA-Z0-9]", "");
                if (wordString.isEmpty()) {
                    continue;
                }

                boolean wordFound = false;
                for (Word word : words) {
                    if (word.getWord().equals(wordString)) {
                        word.incrementFrequency();
                        wordFound = true;
                        break;
                    }
                }

                if (!wordFound) {
                    words.add(new Word(wordString));
                    uniqueWordCount++;
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return uniqueWordCount;
    }

    /**
     * method int n.
     * @param n int
     */
    public void printTopWords(int n) {
        words.sort(null);
        for (int i = 0; i < n && i < words.size(); i++) {
            System.out.println(words.get(i));
        }
    }

    /**
     * main method.
     * @param args unused
     */
    public static void main(String[] args) {
        WordCounter wordCounter = new WordCounter();
        int uniqueWordCount = wordCounter.parseBook("./src/bible.txt");
        System.out.println("Total number of unique words: " + uniqueWordCount);
        System.out.println("Top 10 most frequent words");
        wordCounter.printTopWords(TEN);
    }
}




