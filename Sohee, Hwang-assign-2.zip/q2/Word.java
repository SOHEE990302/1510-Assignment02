package q2;


/**
* class word implements comparable.
* @author SoheeHwang
* @version 2023
*
*/
public class Word implements Comparable<Word> {
        
    /**
    * Sting world.
    */
    private final String word;
        
    /**
    * int frequency.
    */
    private int frequency;

    /**
    * Sting word for word public.
    * @param word
    *          String.
    */
    public Word(String word) {
        this.word = word;
        this.frequency = 1;
    }

    /**
    * retrun word.
    * @return getword.
    */
    public String getWord() {
        return word;
    }

    /**
    * return frequency.
    * @return getfrequeny
    */
    public int getFrequency() {
        return frequency;
    }

    /**
    * increment frequency method.
    */
    public void incrementFrequency() {
        frequency++;
    }

    @Override
    public String toString() {
        return word + ": " + frequency;
    }

    @Override
    public int compareTo(Word other) {
        return other.frequency - this.frequency;
    }
}



