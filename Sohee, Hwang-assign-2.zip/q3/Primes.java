package q3;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * <p>
 * This is where you put your description about what this class does. You don't
 * have to write an essay but you should describe exactly what it does.
 * Describing it will help you to understand the programming problem better.
 * </p>
 *
 * @author Sohee Hwang
 * @version 2023
 */

public class Primes {
    
    /**
     * primes boolean.
     */
    private ArrayList<Boolean> primes;

    /**
     * int primes.
     * @param inputnumber
     *              int primes
     */
    public Primes(int inputnumber) {
        primes = new ArrayList<Boolean>(inputnumber + 1);
        calculatePrimes(inputnumber);
    }

    private void calculatePrimes(int inputnumber) {
        for (int i = 0; i <= inputnumber; i++) {
            primes.add(i, true);
        }
        primes.set(0, false);
        primes.set(1, false);
        for (int i = 2; i <= Math.sqrt(inputnumber); i++) {
            if (primes.get(i)) {
                for (int j = i * i; j <= inputnumber; j += i) {
                    primes.set(j, false);
                }
            }
        }
    }

    /**
     * print primes.
     */
    public void printPrimes() {
        System.out.print("The prime numbers between 0 and " 
                + (primes.size() - 1) 
                 + " are:\n");
        for (int i = 0; i < primes.size(); i++) {
            if (primes.get(i)) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }

    /**
     * count primes.
     * @return countPrimes
     *              int
     */
    public int countPrimes() {
        int count = 0;
        for (int i = 0; i < primes.size(); i++) {
            if (primes.get(i)) {
                count++;
            }
        }
        return count;
    }

    /**
     * boolean prime int x.
     * @param x int
     * @return primes
     */
    public boolean isPrime(int x) {
        if (x < 0 || x >= primes.size()) {
            throw new IllegalArgumentException("x must be in the range [0, " 
        + (primes.size() - 1) + "]");
        }
        return primes.get(x);
    }

    /**
     * scanner upper bound.
     * @param args unused
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int userinput = 0;
        do {
            System.out.println("Enter an upper bound:");
            try {
                userinput = Integer.parseInt(sc.nextLine());
                if (userinput <= 1) {
                    System.out.println("N must be greater than 1.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input: " + e.getMessage());
            }
        } while (userinput <= 1);

        Primes p = new Primes(userinput);
        System.out.println("There are " + p.countPrimes() + " primes:");
        p.printPrimes();
        
        sc.close();
    }
}
