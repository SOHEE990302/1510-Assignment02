package q4;

/**
 * <p>This is where you put your description about what this class does. You
 * don't have to write an essay but you should describe exactly what it does.
 * Describing it will help you to understand the programming problem better.</p>
 *
 * @author Sohee Hwang
 * @version 2023
 */
public class Exponential {
    
    /**
     * int i is 20.
     */
    public static final int TWOZERO = 20;
    
    /**
     * double x is minus 10.
     */
    public static final double MINUSTEN = -10.0; 
    
    /**
     * int 1000.
     */
    public static final int MAX_ITERATIONS = 1000;
    
    /**
     * double epsilon.
     */
    public static final double EPSILON = 1e-15;
        
    /**
     * Calculates the value of the exponential function for a given value of x.
     *
     * @param x the value for which to calculate the exponential function
     * @return the value of e^x
     */
    public static double exp(double x) {
        double sum = 1.0;
        double term = 1.0;
        int k = 1;

        while (k < MAX_ITERATIONS && Math.abs(term) > EPSILON) {
            term *= x / k;
            sum += term;
            k++;
        }

        return sum;
    }

    /**
     * main method.
     * @param args unused
     */
    public static void main(String[] args) {
        double x = MINUSTEN;
        double increment = 1.0;

        System.out.println("x\t\te^x");
        for (int i = 0; i <= TWOZERO; i++) {
            double result = exp(x);
            System.out.printf("%.1f\t\t%.11f\n", x, result);
            x += increment;
        }
    }
}

