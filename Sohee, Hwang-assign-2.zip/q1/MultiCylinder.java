package q1;

/**
 * <p>This is where you put your description about what this class does. You
 * don't have to write an essay but you should describe exactly what it does.
 * Describing it will help you to understand the programming problem better.</p>
 *
 * @author Sohee Hwang
 * @version 2023
 */
public class MultiCylinder {
    /**
     * THREE.
     */
    public static final int THREE = 3;
    
    /**
     * FOUR.
     */
    public static final int FOUR = 4;
    
    /**
     * FIVE.
     */
    public static final int FIVE = 5;
    
    /**
     * SEVEN.
     */
    public static final int SEVEN = 7;
    
    /**
     * TEN.
     */
    public static final int TEN = 10;
    
    
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {     
        Cylinder[] cylinders = new Cylinder[2];
        cylinders[0] = new Cylinder(2, FIVE);
        cylinders[1] = new Cylinder(THREE, SEVEN);

        System.out.println("Before modification:");
        for (Cylinder cylinder : cylinders) {
            System.out.println(cylinder);
            System.out.printf("Volume = %.2f\n", cylinder.volume());
            System.out.printf("Surface area = %.2f\n\n",
                    cylinder.surfaceArea());
        }

        cylinders[0].setRadius(FOUR);
        cylinders[1].setHeight(TEN);

        System.out.println("After modification:");
        for (Cylinder cylinder : cylinders) {
            System.out.println(cylinder);
            System.out.printf("Volume = %.2f\n", cylinder.volume());
            System.out.printf("Surface area = %.2f\n\n", 
                    cylinder.surfaceArea());
        }
    
        System.out.println("Question one was called and ran sucessfully.");
    }

}
