package q1;


/**
 * cylinder class.
 * @author SoheeHwnag
 * @version 2023
 *
 */
public class Cylinder {
    
    /**
     * double radius.
     */
    private double radius;
    
    /**
     * double height.
     */
    private double height;

    /**
     * double radius and height.
     * @param radius
     *          double
     * @param height
     *          double
     */
    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    /**
     * return radius.
     * @return radius
     */
    public double getRadius() {
        return this.radius;
    }

    /**
     * set doulbe radius.
     * @param radius
     *          double
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * get a height.
     * @return height
     */
    public double getHeight() {
        return this.height;
    }

    /**
     * set double height.
     * @param height
     *          double
     */
    public void setHeight(double height) {
        this.height = height;
    }

    /**
     * double volume.
     * @return volume
     */
    public double volume() {
        return Math.PI * this.radius * this.radius * this.height;
    }

    /**
     * double surfacearea.
     * @return surgacearea
     */
    public double surfaceArea() {
        return 2 * Math.PI * this.radius * (this.radius + this.height);
    }
    
    /**
     * return toSting representation of this cylinder.
     * @return toSting
     */
    public String toString() {
        return "Cylinder:\nRadius = " + this.radius 
                + "\nHeight = " + this.height;
    }
}

 


